package com.cazadores.castillo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CastilloApplicationTests {

	@Test
	void contextLoads() {
	}

}
