package com.cazadores.castillo.dto;

public class MensajeRequest {
    public Long getPilarId() {
		return pilarId;
	}
	public void setPilarId(Long pilarId) {
		this.pilarId = pilarId;
	}
	public String getContenidoFragmentado() {
		return contenidoFragmentado;
	}
	public void setContenidoFragmentado(String contenidoFragmentado) {
		this.contenidoFragmentado = contenidoFragmentado;
	}
	private Long pilarId;
    private String contenidoFragmentado;
}