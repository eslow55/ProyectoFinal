package com.cazadores.castillo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cazadores.castillo.dto.MensajeRequest;
import com.cazadores.castillo.dto.ReconstruirMensajeRequest;
import com.cazadores.castillo.model.Mensaje;
import com.cazadores.castillo.service.MensajeService;

@RestController
@RequestMapping("/api/mensajes")
public class MensajeController {

    @Autowired
    private MensajeService mensajeService;

    // 🚀 4. POST – Registrar mensaje táctico fragmentado
    @PostMapping
    public ResponseEntity<Mensaje> registrarMensaje(@RequestBody MensajeRequest request) {
        Mensaje nuevoMensaje = mensajeService.guardarMensaje(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoMensaje);
    }

    // 🔧 5. PUT – Reconstruir un mensaje táctico
    @PutMapping("/{id}/reconstruir")
    public ResponseEntity<Mensaje> reconstruirMensaje(@PathVariable Long id, @RequestBody ReconstruirMensajeRequest request) {
        Mensaje mensajeActualizado = mensajeService.reconstruirMensaje(id, request.getContenidoReconstruido());
        return ResponseEntity.ok(mensajeActualizado);
    }
}