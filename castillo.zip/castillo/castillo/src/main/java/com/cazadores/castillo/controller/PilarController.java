package com.cazadores.castillo.controller;

import com.cazadores.castillo.dto.ActualizarPosicionRequest;
import com.cazadores.castillo.model.Pilar;
import com.cazadores.castillo.service.PilarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/pilares")
public class PilarController {

    @Autowired
    private PilarService pilarService;

    @GetMapping("/{id}")
    public ResponseEntity<Pilar> obtenerPilar(@PathVariable Long id) {
        return ResponseEntity.ok(pilarService.obtenerPilar(id));
    }

    @PostMapping("/crear")
    public ResponseEntity<Pilar> crearPilar(@RequestBody Pilar pilar) {
        Pilar nuevoPilar = pilarService.crearPilar(pilar);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoPilar);
    }
    
    
    @PostMapping("/actualizar-posicion")
    public ResponseEntity<?> actualizarPosicion(@RequestBody ActualizarPosicionRequest request) {
        try {
            Pilar pilarActualizado = pilarService.actualizarPosicion(request);
            
            
            return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                "mensaje", "Posición actualizada exitosamente.",
                "pilar", pilarActualizado
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error en datos enviados");
        }
    }
}