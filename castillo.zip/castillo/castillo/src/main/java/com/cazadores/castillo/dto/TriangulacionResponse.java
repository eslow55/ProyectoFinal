package com.cazadores.castillo.dto;

public class TriangulacionResponse {

    private Posicion posiblePosicionMuzan;
    private Double nivelConfianza;
    private String descripcion;

    // Constructor vacío
    public TriangulacionResponse() {
    }

    // Constructor manual que usa el Servicio (importante para tu examen)
    public TriangulacionResponse(int x, int y, Double nivelConfianza, String descripcion) {
        this.posiblePosicionMuzan = new Posicion(x, y);
        this.nivelConfianza = nivelConfianza;
        this.descripcion = descripcion;
    }

    // --- Getters y Setters de la clase principal ---
    public Posicion getPosiblePosicionMuzan() {
        return posiblePosicionMuzan;
    }

    public void setPosiblePosicionMuzan(Posicion posiblePosicionMuzan) {
        this.posiblePosicionMuzan = posiblePosicionMuzan;
    }

    public Double getNivelConfianza() {
        return nivelConfianza;
    }

    public void setNivelConfianza(Double nivelConfianza) {
        this.nivelConfianza = nivelConfianza;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    // --- Clase Interna Estática ---
    public static class Posicion {
        private int x;
        private int y;

        public Posicion() {}

        public Posicion(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public int getX() {
            return x;
        }

        public void setX(int x) {
            this.x = x;
        }

        public int getY() {
            return y;
        }

        public void setY(int y) {
            this.y = y;
        }
    }
}