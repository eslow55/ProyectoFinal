package com.cazadores.castillo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cazadores.castillo.dto.TriangulacionResponse;
import com.cazadores.castillo.service.InteligenciaService;

@RestController
@RequestMapping("/api/inteligencia")
public class InteligenciaController {

    @Autowired
    private InteligenciaService inteligenciaService;

    // ✅ 2. GET – Obtener triangulación estimada del enemigo
    @GetMapping("/triangulacion")
    public ResponseEntity<TriangulacionResponse> obtenerTriangulacion() {
        return ResponseEntity.ok(inteligenciaService.calcularTriangulacion());
    }
}