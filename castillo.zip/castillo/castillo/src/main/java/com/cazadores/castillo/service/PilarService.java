package com.cazadores.castillo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cazadores.castillo.dto.ActualizarPosicionRequest;
import com.cazadores.castillo.model.Pilar;
import com.cazadores.castillo.repository.PilarRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class PilarService {

    @Autowired
    private PilarRepository pilarRepository;

    public Pilar obtenerPilar(Long id) {
        return pilarRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Pilar no encontrado con ID: " + id));
    }
    
    public Pilar crearPilar(Pilar pilar) {
        return pilarRepository.save(pilar);
    }

    public List<Pilar> obtenerTodos() {
        return pilarRepository.findAll();
    }

    public Pilar actualizarPosicion(ActualizarPosicionRequest request) {
        // Buscamos si el pilar existe para actualizarlo
        Pilar pilar = pilarRepository.findById(request.getPilarId())
                .orElseThrow(() -> new EntityNotFoundException("El Pilar no existe"));

        pilar.setPosX(request.getPosX());
        pilar.setPosY(request.getPosY());
        pilar.setEstado(request.getEstado());

        return pilarRepository.save(pilar);
    }
}