package com.cazadores.castillo.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name = "mensajes")
public class Mensaje {

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getPilarId() {
		return pilarId;
	}

	public void setPilarId(Long pilarId) {
		this.pilarId = pilarId;
	}

	public String getContenidoFragmentado() {
		return contenidoFragmentado;
	}

	public void setContenidoFragmentado(String contenidoFragmentado) {
		this.contenidoFragmentado = contenidoFragmentado;
	}

	public String getContenidoReconstruido() {
		return contenidoReconstruido;
	}

	public void setContenidoReconstruido(String contenidoReconstruido) {
		this.contenidoReconstruido = contenidoReconstruido;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long pilarId; // Relación lógica
    private String contenidoFragmentado;
    private String contenidoReconstruido;
    
    private LocalDateTime timestamp;

    @PrePersist
    public void prePersist() {
        this.timestamp = LocalDateTime.now();
    }
}