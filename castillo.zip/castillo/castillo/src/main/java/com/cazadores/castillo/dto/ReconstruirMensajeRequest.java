package com.cazadores.castillo.dto;

public class ReconstruirMensajeRequest {
    public String getContenidoReconstruido() {
		return contenidoReconstruido;
	}

	public void setContenidoReconstruido(String contenidoReconstruido) {
		this.contenidoReconstruido = contenidoReconstruido;
	}

	private String contenidoReconstruido;
}