package com.cazadores.castillo.service;

import com.cazadores.castillo.dto.MensajeRequest;
import com.cazadores.castillo.model.Mensaje;
import com.cazadores.castillo.repository.MensajeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.persistence.EntityNotFoundException;

@Service
public class MensajeService {

    @Autowired
    private MensajeRepository mensajeRepository;

    public Mensaje guardarMensaje(MensajeRequest request) {
        Mensaje mensaje = new Mensaje();
        mensaje.setPilarId(request.getPilarId());
        mensaje.setContenidoFragmentado(request.getContenidoFragmentado());
        return mensajeRepository.save(mensaje);
    }

    public Mensaje reconstruirMensaje(Long id, String contenidoReconstruido) {
        Mensaje mensaje = mensajeRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("No existe mensaje con ese ID"));
        
        mensaje.setContenidoReconstruido(contenidoReconstruido);
        return mensajeRepository.save(mensaje);
    }
}