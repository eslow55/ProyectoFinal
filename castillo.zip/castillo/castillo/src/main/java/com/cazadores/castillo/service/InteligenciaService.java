package com.cazadores.castillo.service;

import com.cazadores.castillo.dto.TriangulacionResponse;
import com.cazadores.castillo.model.Pilar;
import com.cazadores.castillo.repository.PilarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InteligenciaService {

    @Autowired
    private PilarRepository pilarRepository;

    public TriangulacionResponse calcularTriangulacion() {
        List<Pilar> pilares = pilarRepository.findAll();
        
        if (pilares.isEmpty()) {
            return new TriangulacionResponse(0, 0, 0.0, "Sin datos suficientes");
        }

        // Algoritmo simple: Promedio de coordenadas (Centroide)
        double promX = pilares.stream().mapToInt(Pilar::getPosX).average().orElse(0);
        double promY = pilares.stream().mapToInt(Pilar::getPosY).average().orElse(0);

        // Suposición narrativa: Muzan suele estar en el centro geométrico de los cazadores
        return new TriangulacionResponse(
                (int) promX, 
                (int) promY, 
                0.78, 
                "Probabilidad alta de presencia demoníaca en las coordenadas dadas."
        );
    }
}